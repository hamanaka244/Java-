package jsys.sales.common;
//例外処理
public class SalesSystemException extends Exception{

	public SalesSystemException(String message) {
		super(message);
	}
}
