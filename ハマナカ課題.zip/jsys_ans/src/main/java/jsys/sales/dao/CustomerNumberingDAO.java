package jsys.sales.dao;

public class CustomerNumberingDAO {

}
