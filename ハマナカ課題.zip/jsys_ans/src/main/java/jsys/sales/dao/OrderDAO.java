package jsys.sales.dao;

public class OrderDAO {

}
