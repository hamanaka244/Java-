package jsys.sales.web;

import javax.servlet.http.HttpServletRequest;

public interface ActionIF {
	public String execute(HttpServletRequest request);
}
