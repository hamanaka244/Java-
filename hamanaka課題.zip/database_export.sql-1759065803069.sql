INSERT INTO jsysdb.employeedb (employee_no,employee_name,password) VALUES
	 (1,'太郎',9999),
	 (2,'猫',9999);
